	<!-- footer -->
    
     <div class="footer">
    	<div class="footer-content">
        	
            <div class="footer-col1">
            
                Copyright &copy; pixelzee - 
                <script type="text/javascript">
                    var theDate=new Date();
                    document.write(theDate.getFullYear());
                </script>
                
            </div>
            
            <div class="footer-col2">
                
                Creating simple, creative and userfriendly websites and apps
                <br /><br />
                Blog powered by <a href="http://wordpress.com" target="_blank">Wordpress</a>
                
            </div>
            
            <div class="footer-col3">
            
                <a href="../index.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="/">Blog</a>
                <br /><br />
                <a href="../about.php">About</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="../contact.php">Contact</a>
                <br /><br />
                <a href="../work.php">Work</a>
            
            </div>
            
            <div class="footer-col4">
            
                <b>pixelzee</b><br />
                <a href="mailto: info@pixelzee.com">info@pixelzee.com</a>
            
            </div>
        
        </div>
    </div>
    
    <!-- end footer -->
	
    <?php wp_footer(); ?>
   
</body>
</html>